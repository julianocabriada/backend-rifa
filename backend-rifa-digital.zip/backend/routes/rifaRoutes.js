const express = require('express');
const router = express.Router();
const RifaController = require('../controllers/RifaController');
router.post('/', RifaController.createRifa);
router.get('/', RifaController.getRifas);
module.exports = router;