const express = require('express');
const router = express.Router();
const PagamentoController = require('../controllers/PagamentoController');
router.post('/', PagamentoController.processarPagamento);
module.exports = router;