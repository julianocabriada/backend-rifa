exports.createRifa = (req, res) => { res.status(201).json({ message: 'Rifa criada com sucesso' }); };
exports.getRifas = (req, res) => { res.json([]); };