# Backend - Rifa Digital

1. `npm install`
2. Configure `.env`
3. `npx prisma generate`
4. `node server.js`